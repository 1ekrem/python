import pyodbc

for driver in pyodbc.drivers():
    print(driver)

# Driver da Microsoft para arquivos texto (*.txt; *.csv)
# Driver do Microsoft Access (*.mdb)
# Driver do Microsoft dBase (*.dbf)
# Driver do Microsoft Excel(*.xls)
# Driver do Microsoft Paradox (*.db )
# Microsoft Access Driver (*.mdb)
# Microsoft Access-Treiber (*.mdb)
# Microsoft dBase Driver (*.dbf)
# Microsoft dBase-Treiber (*.dbf)
# Microsoft Excel Driver (*.xls)
# Microsoft Excel-Treiber (*.xls)
# Microsoft ODBC for Oracle
# Microsoft Paradox Driver (*.db )
# Microsoft Paradox-Treiber (*.db )
# Microsoft Text Driver (*.txt; *.csv)
# Microsoft Text-Treiber (*.txt; *.csv)
# SQL Server
# ODBC Driver 17 for SQL Server
# SQL Server Native Client 11.0