import datetime as dt

x = dt.datetime.today().strftime('%Y-%m-%d')

print(x)