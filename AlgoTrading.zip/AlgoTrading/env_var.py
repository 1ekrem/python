api_key = 'bbf66c10187326f9b777ad3ff0d0c9d1'
email = 'erikersay@gmail.com'
pwd = '1234567e'