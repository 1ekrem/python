import openpyxl
import os


def copyRange(startCol, startRow, endCol, endRow, sheet):
    rangeSelected = []
    for i in range(startRow, endRow+1,1):
        rowSelected=[]
        for j in range(startCol, endCol+1,1):
            rowSelected.append(sheet.cell(row=i, column=j).value)
        rangeSelected.append(rowSelected)
    return rangeSelected

def pasteRange(startCol, startRow, endCol, endRow, sheetReceiving, copiedData):
    countRow=0 
    for i in range(startRow, endRow+1, 1):
        countCol=0
        for j in range(startCol, endCol+1, 1):
            sheetReceiving.cell(row=i, column=j).value = copiedData[countRow][countCol]
            countCol += 1
        countRow += 1

def createAnalysis(ticker):
    print("Processing {}...".format(ticker))
    
    wb = openpyxl.load_workbook("C:\\PythonClass\\ta-ticker\\{}_SMAanalysis.xlsx".format(ticker))
    sheet = wb["Sheet1"]

    template = openpyxl.load_workbook("C:\\PythonClass\\AlgoTrading\\AnalysisTemplate.xlsx")
    temp_sheet=template["result"]
    
    selectedRange3 = copyRange(1,2,26,251,sheet)
    pasteRange(1,2,26,251,temp_sheet,selectedRange3)

    template.save("C:\\Users\\ekrem\\Desktop\\Trade Analysis\\{}_TAanalysis.xlsx".format(ticker))
    print("Report is generated for {}! Please check your Trade Analysis folder on your desktop.\n".format(ticker))

    os.remove('C:\\PythonClass\\ta-ticker\\{}_SMAanalysis.xlsx'.format(ticker))
 